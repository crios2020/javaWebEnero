package ar.com.eduit.curso.java.web.repositories.list;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import java.util.ArrayList;
import java.util.List;

public class ArticuloRepository implements I_ArticuloRepository {
    private List<Articulo>list;
    
    public ArticuloRepository (){
        list=new ArrayList();
        save(new Articulo(1,"Parlante USB",3000));
        save(new Articulo(2,"Mouse Optico",1000));
        save(new Articulo(3,"Monitor 19",10000));
        save(new Articulo(4,"Teclado usb",2000));
        save(new Articulo(5,"Parlante BT",5000));
    }

    @Override
    public void save(Articulo articulo) {
        list.add(articulo);
    }

    @Override
    public void remove(Articulo articulo) {
        list.remove(articulo);
    }

    @Override
    public List<Articulo> getAll() {
        return list;
    }
    
}