package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.rest.ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.rest.ClienteRepository;

public class TestRepository {
    public static void main(String[] args) {
        String url="http://localhost:8086/Clase09/resources/clientes/v1";
        I_ClienteRepository cr=new ClienteRepository(url);
        Cliente cliente=new Cliente("Jimena", "Celina", "Wiliams_1234", "");
        cr.save(cliente);
        System.out.println(cliente);
        cr.getAll().forEach(System.out::println);
        System.out.println("**************************************************");
        System.out.println(cr.getById(20));
        System.out.println("**************************************************");
        cr.getLikeApellido("sa").forEach(System.out::println);
        
        
        url="http://localhost:8086/Clase09/resources/articulos/v1";
        I_ArticuloRepository ar=new ArticuloRepository(url);
        Articulo articulo=new Articulo(304, "Marcador_Rojo", 90);
        ar.save(articulo);
        System.out.println(articulo);
        
        System.out.println("*************************************************");
        ar.getAll().forEach(System.out::println);
        System.out.println("*************************************************");
        System.out.println(ar.getById(105));
        System.out.println("*************************************************");
        ar.getLikeDescripcion("ma").forEach(System.out::println);
        
        
    }
}