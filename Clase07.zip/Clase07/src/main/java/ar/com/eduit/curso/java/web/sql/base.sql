drop database if exists negocioWeb;
create database negocioWeb;
use negocioWeb;
-- show tables;

create table articulos(
    id int primary key,
    descripcion varchar(25) not null,
    precio float
);

create table clientes(
    id int auto_increment primary key,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    direccion varchar(50),
    comentarios varchar(250)
);

create table vendedores(
    id int auto_increment primary key,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    nroLegajo int,
    sueldoBasico float
);