package ar.com.eduit.curso.java.web.managed.bean;

import ar.com.eduit.curso.java.web.enums.EstadoCivil;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named("estadoCivilMB")
@SessionScoped
public class EstadoCivilManagedBean implements Serializable {
    public List<EstadoCivil>getEstados(){
        return Arrays.asList(EstadoCivil.values());
    }
}