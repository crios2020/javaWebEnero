package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.connector.Connector;
import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ArticuloRepository;
//import ar.com.eduit.curso.java.web.repositories.list.ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.list.ArticuloRepositoryFactory;

public class TestRepository {
    public static void main(String[] args) {
        //I_ArticuloRepository ar=new ArticuloRepository();
        //I_ArticuloRepository ar=ArticuloRepositoryFactory.getArticuloRepository();
        
        I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
        
        //ar.save(new Articulo(101,"Parlante USB",3000));
        //ar.save(new Articulo(102,"Mouse Optico",1000));
        //ar.save(new Articulo(103,"Monitor 19",10000));
        //ar.save(new Articulo(104,"Teclado usb",2000));
        //ar.save(new Articulo(105,"Parlante BT",5000));
        
        //for(Articulo a:ar.getAll()) System.out.println(a);
        
        //ar.getAll().forEach(a->System.out.println(a));
        ar.getAll().forEach(System.out::println);
        System.out.println("*************************************************");
        System.out.println(ar.getById(4));
        System.out.println("*************************************************");
        ar.getLikeDescripcion("par").forEach(System.out::println);
        

        
    }
}