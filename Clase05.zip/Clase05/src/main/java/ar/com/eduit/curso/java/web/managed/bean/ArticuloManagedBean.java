package ar.com.eduit.curso.java.web.managed.bean;

import ar.com.eduit.curso.java.web.connector.Connector;
import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ArticuloRepository;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;


@Named("articuloMB")
@SessionScoped
public class ArticuloManagedBean implements Serializable {
    private I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
    public List<Articulo> getAll(){
        return ar.getAll();
    }
}