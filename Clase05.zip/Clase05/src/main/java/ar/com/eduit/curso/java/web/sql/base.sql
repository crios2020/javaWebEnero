drop database if exists negocioWeb;
create database negocioWeb;
use negocioWeb;

create table articulos(
    id int primary key,
    descripcion varchar(25) not null,
    precio float
);


select * from articulos;