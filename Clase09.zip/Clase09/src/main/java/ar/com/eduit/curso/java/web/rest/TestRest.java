package ar.com.eduit.curso.java.web.rest;

import ar.com.eduit.curso.java.web.connector.Connector;
import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.jdbc.ArticuloRepository;
import com.google.gson.Gson;
import java.util.List;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("test")
public class TestRest {
    @GET
    public String info(){
        return "Servicio TEST Activo";
    }
    
    @GET
    @Path("info2")
    public String info2(){
        return "INFO2";
    }
    
    @GET
    @Path("suma")
    public String sumar(@QueryParam("num1")int numero1, @QueryParam("num2")int numero2){
        int total=numero1+numero2;
        return total+"";
    }
    
    @GET
    @Path("articulos/all")
    @Produces(MediaType.APPLICATION_JSON)
    public String getAll(){
        return new Gson().toJson(
                    new ArticuloRepository(Connector.getConnection())
                        .getAll());
    }
    
    @GET
    @Path("articulos/likeDescripcion")
    @Produces(MediaType.APPLICATION_JSON)
    public String getLikeDescripcion(@QueryParam("descripcion")String descripcion){
        return new Gson().toJson(
            new ArticuloRepository(Connector.getConnection())
                .getLikeDescripcion(descripcion));
    }
    
    @GET
    @Path("titulo")
    @Produces(MediaType.TEXT_PLAIN)
    public String titulo(){
        return "<h1>Curso Java Wev Api</h1>";
    }
    
    @GET
    @Path("titulo2")
    @Produces(MediaType.TEXT_HTML)
    public String titulo2(){
        return "<h1>Curso Java Wev Api</h1>";
    }
    
    @GET
    @Path("titulo3")
    @Produces("text/html")
    public String titulo3(){
        return "<h1>Curso Java Wev Api</h1>";
    }
}