package ar.com.eduit.curso.java.web.rest;

import ar.com.eduit.curso.java.web.connector.Connector;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ArticuloRepository;
import com.google.gson.Gson;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("articulos/v1")
public class ArticuloRest {
    private final I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
    
    @GET
    public String info(){
        return "Servicio de Clientes V1 Activo.";
    }
    
    @GET
    @Path("all")
    @Produces(MediaType.APPLICATION_JSON)
    public String getAll(){
        return new Gson().toJson(ar.getAll());
    }
    
    @GET
    @Path("byId")
    @Produces(MediaType.APPLICATION_JSON)
    public String getById(@QueryParam("id") int id){
        return new Gson().toJson(ar.getById(id));
    }
    
    @GET
    @Path("likeDescripcion")
    @Produces(MediaType.APPLICATION_JSON)
    public String getLikeApellido(@QueryParam("descripcion")String descripcion){
        return new Gson().toJson(ar.getLikeDescripcion(descripcion));
    }
    
}