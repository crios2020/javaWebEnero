drop database if exists colegio;
create database colegio;
use colegio;
create table cursos(
    id int auto_increment primary key,
    titulo varchar(20) not null,
    profesor varchar(20) not null,
    dia enum('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES'),
    turno enum('MAÑANA','TARDE','NOCHE')
);
create table alumnos(
    id int auto_increment primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    edad int,
    idCurso int not null
);
alter table alumnos 
    add constraint fk_alumnos_idCurso
    foreign key(idCurso)
    references cursos(id);


insert into cursos values (null,'Java','Ríos','MIERCOLES','MAÑANA');
select * from cursos;

insert into alumnos values(null,'Rodrigo','Lopez',23,1);
select * from alumnos;

insert into cursos (titulo,profesor) values ('java','Gomez');
delete from cursos where dia is null;
select * from alumnos where edad=(select max(edad) from alumnos);