package ar.com.eduit.curso.java.utils.html;

import java.lang.reflect.Field;
import java.util.List;

public class HtmlTable <E>{
    public String getTable(List<E> list){
        if(list==null || list.isEmpty() ) return "";
        String table="<table>";
        E e=list.get(0);
        Field[] campos=e.getClass().getDeclaredFields();
        table+="<tr>";
        for(Field f:campos){
            table+="<th>"+f.getName()+"</th>";
        }
        table+="</tr>";
        for(E o:list){
            table+="<tr>";
            for(Field f:campos){
                table+="<td>";
                String metodo="get"
                            +f.getName().substring(0, 1).toUpperCase()
                            +f.getName().substring(1);
                    System.out.println(metodo);
                try {
                    table+=e.getClass().getDeclaredMethod(metodo).invoke(o, null);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                table+="</td>";
            }
            table+="</tr>";
        }
        table+="</table>";
        return  table;
    }
}
