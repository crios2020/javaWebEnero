package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connector.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;
import ar.com.eduit.curso.java.utils.files.FileText;
import ar.com.eduit.curso.java.utils.files.I_File;
import java.sql.Connection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestStream {
    private final static Connection connection = new Connector().getConnection();
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository(connection);
        I_AlumnoRepository ar=new AlumnoRepository(connection);
        I_File fileText=new FileText("res/texto.txt");
        
        Stream<Curso>cursos=cr.getAll().stream();
        Stream<Alumno>alumnos=ar.getAll().stream();
        Stream<String>lineas=fileText.getLines().stream();
        
        //select * from cursos;
        //cursos.forEach(curso->System.out.println(curso));
        //cursos.forEach(System.out::println);
        
        //select * from alumnos;
        //alumnos.forEach(System.out::println);
        
        //select * from lineas;
        //lineas.forEach(System.out::println);
        
        
        //select * from alumnos where edad>30;
        //alumnos
        //        .filter(alumno->alumno.getEdad()>30)
        //        .forEach(System.out::println);
        
        
        //select * from alumnos where edad between 20 and 30;
        //alumnos
        //        .filter(alumno->alumno.getEdad()>=20 && alumno.getEdad()<=30)
        //        .forEach(System.out::println);
        
        //select * from cursos where titulo='java' and dia='JUEVES';
        //cursos
        //        .filter(curso->
        //                    curso.getTitulo().equalsIgnoreCase("java") 
        //                    &&
        //                    curso.getDia()==Dia.JUEVES
        //        )
        //        .forEach(System.out::println);
        
        //select * from cursos where titulo like '%ja%' and turno='TARDE';
        //cursos
        //       .filter(curso->
        //                    curso.getTitulo().toLowerCase().contains("ja")
        //                    && 
        //                    curso.getTurno()==Turno.TARDE
        //        )
        //        .forEach(System.out::println);
        
        //select * from cursos where titulo like '%ja%' order by dia;
        //cursos
        //        .filter(curso->curso.getTitulo().toLowerCase().contains("ja"))
        //        .sorted(Comparator.comparing(Curso::getDia))
        //        .forEach(System.out::println);
        
        //cursos
        //        .filter(curso->curso.getTitulo().toLowerCase().contains("ja"))
        //        .sorted()
        //        .forEach(System.out::println);
        
        
        //select * from alumnos where edad=(select max(edad) from alumnos);
        //System.out.println(alumnos.max(Comparator.comparingInt(Alumno::getEdad)).get());
        List<Alumno>list=alumnos.collect(Collectors.toList());
        int edadMaxima=list.stream().max(Comparator.comparingInt(Alumno::getEdad)).get().getEdad();
        System.out.println("edad Máxima: "+edadMaxima);
        
        list.stream()
                .filter(alumno->alumno.getEdad()==edadMaxima)
                .forEach(System.out::println);
        
        
        
        
        
    }
    
}