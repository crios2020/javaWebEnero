package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connector.Connector;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.utils.files.FileText;
import ar.com.eduit.curso.java.utils.files.I_File;

public class FileTest {
    public static void main(String[] args) {
        String file="res/texto.txt";
        
        I_File fileText=new FileText(file);
        fileText.setText("Curso de Java!\n");
        fileText.appendText("Hoy es Viernes!!!!\n");
        
        //System.out.println(fileText.getText());
        //fileText.print();
        
        fileText.addLine("Primavera.");
        fileText.addLine("Verano.");
        fileText.addLine("Otoño.");
        fileText.addLine("Invierno.");
        fileText.addLine("Primavera.");
        fileText.addLine("Primavera.");
        
        I_AlumnoRepository ar=new AlumnoRepository(new Connector().getConnection());
        
        ar.getAll().forEach(a->fileText.addLine(a.getNombre()));
        
        //fileText.getLines().forEach(System.out::println);
        //fileText.getTreeSet().forEach(System.out::println);
        fileText.getLines("an").forEach(System.out::println);
        
        /*
        String texto="";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="h";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="o";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="l";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="a";
        System.out.println(texto+"\t"+texto.hashCode());
        */
        //texto="";
        //for(int a=0;a<=200000;a++){
        //    texto+="x";
        //}
        
        //StringBuilder sb=new StringBuilder();
        //for(int a=0;a<=200000;a++){
        //    sb.append("x");
        //}
        
    }
}
