package ar.org.centro8.curso.java.test;
import ar.org.centro8.curso.java.entities.Curso;
import java.time.LocalTime;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
public class TestJPA {
    public static void main(String[] args) {
        System.out.println("1*************************************************");
        System.out.println(LocalTime.now());
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        System.out.println("2*************************************************");
        System.out.println(LocalTime.now());
        EntityManager em=emf.createEntityManager();
        
        Curso curso=new Curso("Jardineria","Rios","JUEVES","NOCHE");
        
        em.getTransaction().begin();
        em.persist(curso);
        em.getTransaction().commit();
        
        //System.out.println(curso);
        
        //em.getTransaction().begin();
        Query query=em.createNamedQuery("Curso.findById");
        //query.setParameter("id", 16);
        //em.remove(query.getSingleResult());
        //em.getTransaction().commit();
        
        query=em.createNamedQuery("Curso.findById");
        //query.getResultList().size();
        //query.setParameter("id", 12);
        //curso=(Curso)query.getSingleResult();
        //if(curso!=null){
        //    curso.setDia("VIERNES");
        //    curso.setTurno("TARDE");
        //    em.getTransaction().begin();
        //    em.persist(curso);
        //    em.getTransaction().commit();
        //}
        
        System.out.println("**************************************************");
        //em.createNamedQuery("Curso.findAll").getResultList().forEach(System.out::println);
        //em.createQuery("from clientes select *").getResultList().stream().forEach(cnsmr);
        
        //Query query=em.createNamedQuery("Curso.findByTitulo");
        //query.setParameter("titulo", "java");
        //query.getResultList().forEach(System.out::println);
        
        em.close();
        System.out.println("3*************************************************");
        System.out.println(LocalTime.now());
        emf.close();
        System.out.println(LocalTime.now());
        System.out.println("4*************************************************");
    }
}