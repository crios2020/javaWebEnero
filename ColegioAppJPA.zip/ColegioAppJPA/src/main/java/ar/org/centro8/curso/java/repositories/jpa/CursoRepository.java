package ar.org.centro8.curso.java.repositories.jpa;
import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
public class CursoRepository implements I_CursoRepository{
    private EntityManagerFactory emf;

    public CursoRepository(EntityManagerFactory emf) {
        this.emf = emf;
    }
 
    @Override
    public void save(Curso curso) {
        if(curso==null) return;
        EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(curso);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public void remove(Curso curso) {
       if(curso==null) return;
       EntityManager em=emf.createEntityManager();
       em.getTransaction().begin();
       em.remove(em.merge(curso));
       em.getTransaction().commit();
       em.close();
    }

    @Override
    public void update(Curso curso) {
       if(curso==null) return;
       EntityManager em=emf.createEntityManager();
       em.getTransaction().begin();
       em.persist(em.merge(curso));
       em.getTransaction().commit();
       em.close();
    }

    @Override
    public List<Curso> getAll() {
        List<Curso> list=new ArrayList();
        EntityManager em=emf.createEntityManager();
        list=(List<Curso>)em.createNamedQuery("Curso.findAll").getResultList();
        em.close();
        return list;
    }

    
}