package clase04client;
//jdk LTS
import ar.com.eduit.curso.java.web.entities.Articulo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.net.URI;

import java.net.http.HttpClient;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpClient.Version;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.List;

/*
jdk 9 o 10 no lts
import jdk.incubator.http.HttpClient;
import jdk.incubator.http.HttpRequest;
import jdk.incubator.http.HttpResponse;
import jdk.incubator.http.HttpResponse.BodyHandler;
        */

public class Clase04Client {

    public static void main(String[] args) throws Exception {
        
        /*
        
        LTS: Long Term Support      8 años
        
        Hasta JDK 8 eran versiones LTS
        jdk 9 - jdk 10 NO LTS
        jdk 11  LTS
        jdk 12 - 13 - 14 - 15 -16 NO LTS
        jdk 17  LTS
        
        */
        
        // Cliente TCP/IP - HTTP - Rest
        
        //Versión JDK9 HTTP2
        /*
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                  .uri(URI.create("http://localhost:8080"))
                  .GET()
                  .build();


            try {
            HttpResponse<String> respuesta=client.send(request, BodyHandler.asString());
            System.out.println(respuesta.body());
          } catch (IOException | InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
          }   
        */
        
        //JDK 11 HTTP 2
        
        /*
        HttpClient client = HttpClient.newBuilder().version(HttpClient.Version.HTTP_2).build();

        HttpResponse<String> response = client
                .send(
                        HttpRequest
                                .newBuilder(new URI("http://localhost:8080/Clase04/ArticuloAll")).headers("User-Agent", "Mozilla/5.0 (X11; Linux x86_64; rv:56.0) Gecko/20100101 Firefox/56.0").GET().build(), HttpResponse.BodyHandlers.ofString());

        System.out.println("Status Code: " + response.statusCode());
        System.out.println("Headers:");
        response.headers().map().entrySet().forEach(System.out::println);
        System.out.println("Body:");
        System.out.println(response.body());
        */
        
        //JDK 8 HTTP 1
        
        /*
        String url;
        
        url="http://localhost:8080/Clase04/ArticuloAll";
        
        HttpClient client=HttpClient.newHttpClient();
        HttpRequest request=HttpRequest.newBuilder().uri(URI.create(url)).build();
        HttpResponse<String> response=client.send(request, HttpResponse.BodyHandlers.ofString());
        
        System.out.println(response.body());
        */
        System.out.println("****************************************************");
        System.out.println(getResponse("http://servicios.usig.buenosaires.gob.ar/normalizar/?direccion=callao%20y%20corrientes,%20caba"));
        System.out.println("****************************************************");
        System.out.println(getResponse("http://localhost:8080/Clase04/ArticuloAlta?id=8&descripcion=Taladro&precio=5000"));
        System.out.println("****************************************************");
        System.out.println(getResponse("http://localhost:8080/Clase04/ArticuloAll"));
        System.out.println("****************************************************");
        System.out.println(getResponse("http://localhost:8080/Clase04/ArticuloLikeDescripcion?descripcion=par"));
        System.out.println("****************************************************");
        System.out.println(getResponse("http://localhost:8080/Clase04/ArticuloById?id=2"));
        
        System.out.println("****************************************************");
        
        List<Articulo> list=new Gson()
                .fromJson(
                        getResponse("http://localhost:8080/Clase04/ArticuloAll"),
                        new TypeToken<List<Articulo>>(){}.getType());
        list.forEach(System.out::println);
                
    }
    
    public static String getResponse(String url){
        try{
            HttpClient client=HttpClient.newHttpClient();
            HttpRequest request=HttpRequest.newBuilder().uri(URI.create(url)).build();
            HttpResponse<String> response=client.send(request, HttpResponse.BodyHandlers.ofString());
            return response.body();
        }catch(Exception e){
            return "error";
        }
    }

}
