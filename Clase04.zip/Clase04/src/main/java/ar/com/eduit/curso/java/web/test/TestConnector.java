package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.connector.Connector;
import java.sql.ResultSet;

public class TestConnector {
    public static void main(String[] args) {
        try (ResultSet rs=Connector.getConnection().createStatement().executeQuery("select version()")){
            if(rs.next()){
                System.out.println(rs.getString(1));
                System.out.println("Se conecto al Server!");
            }else{
                System.out.println("No se conecto al Server!");
            }
        }catch(Exception e){
            System.out.println("No se conecto al Server!");
            System.out.println(e);
        }
    }
}