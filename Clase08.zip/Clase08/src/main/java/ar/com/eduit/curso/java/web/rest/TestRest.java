package ar.com.eduit.curso.java.web.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("test")
public class TestRest {
    @GET
    public String info(){
        return "Servicio TEST Activo";
    }
    
    @GET
    @Path("info2")
    public String info2(){
        return "INFO2";
    }
}