package ar.com.eduit.curso.java.web.resources;

import java.io.Closeable;
import java.io.IOException;

public class Lector implements Closeable{
    private String file;

    public Lector(String file) {
        this.file = file;
    }
    
    public void leer(){
        System.out.println("Texto Archivo!");
    }

    @Override
    public void close() throws IOException {
        System.out.println("Se Cerro el Archivo!!");
    }
    
    
}