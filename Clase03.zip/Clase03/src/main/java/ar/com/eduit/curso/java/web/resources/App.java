package ar.com.eduit.curso.java.web.resources;

public class App {
    public static void main(String[] args) {
        
        //Try With Resources    JDK 7 o sup.
        try (Lector lector=new Lector("texto.txt")) {
            lector.leer();
            //throw new Exception();
            //lector.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        
        //Esto no se debe hacer!!!
        /*
        Lector lector=null;
        try {
            lector=new Lector("c:/texto.txt");
            lector.leer();
            lector.close();
        } catch (Exception e) {
            System.out.println(e);
            if(lector!=null){
                try{
                    lector.close();
                }catch(Exception ex){
                    System.out.println(ex);
                }
            }
        } 
        */
    }
}