package ar.com.eduit.curso.java.web.services;

import ar.com.eduit.curso.java.web.repositories.list.ArticuloRepository;

public class ArticuloRepositoryFactory {
    private static ArticuloRepository ar=null;
    private ArticuloRepositoryFactory(){}
    public static ArticuloRepository getArticuloRepository(){
        if(ar==null) ar=new ArticuloRepository();
        return ar;
    }
}